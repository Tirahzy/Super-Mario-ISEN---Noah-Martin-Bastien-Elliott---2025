
#include "fonction.h"

int main(int argc, char *argv[])
{
    srand(time(NULL));

    if (SDL_Init(SDL_INIT_VIDEO) != 0 || TTF_Init() != 0)
    {
        fprintf(stderr, "Erreur SDL ou TTF_Init : %s\n", SDL_GetError());
        return 1;
    }

    TTF_Font *police = TTF_OpenFont("fonts/arial.ttf", 24);
    if (!police)
    {
        fprintf(stderr, "Erreur chargement police : %s\n", TTF_GetError());
        SDL_Quit();
        return 1;
    }

    SDL_Window *fenetre = creerFenetre("Super Mario ISEN");
    SDL_Renderer *renderer = creerRenderer(fenetre);
    TexturesJeu textures = chargerTextures(renderer);

    int startX = 100;
    int startY = (MAP_HAUTEUR - 3) * BLOC_SIZE - BLOC_SIZE;
    Mario mario = {{startX, startY, BLOC_SIZE, BLOC_SIZE}, 0};
    Champignon champi = {{0, 0, BLOC_SIZE, BLOC_SIZE}, 0, 0.0f};

    Touches touches = {0, 0, 0};
    int enSaut = 0;
    float vitesseSaut = 0.0f;
    int cameraX = 0;
    int nbPieces = 0;
    int scoreFinal = 0;
    int current_level = 1;
    int continuer = 1;
    int etatJeu = ETAT_MENU;
    ScoreJeu scoreJeu = {0, 3};

    initialiserMap(current_level);
    initialiserCarapaces();
    initialiserEffets();

    Bouton boutonsMenu[2];
    initialiserBoutons(boutonsMenu, 2);

    Bouton boutonsNiveauTermine[2] = {
        {{380, 200, 200, 50}, strdup("Niveau Suivant"), 0},
        {{380, 270, 200, 50}, strdup("Menu Principal"), 0}};

    Bouton boutonsGameOver[2] = {
        {{380, 200, 200, 50}, strdup("Rejouer"), 0},
        {{380, 270, 200, 50}, strdup("Menu Principal"), 0}};

    while (continuer)
    {
        switch (etatJeu)
        {
            // Le reste du code est supposé identique...
            // Ici, on se concentre sur la correction de structure et appels aux fonctions
            default:
                break;
        }
    }

    free(boutonsNiveauTermine[0].texte);
    free(boutonsNiveauTermine[1].texte);
    free(boutonsGameOver[0].texte);
    free(boutonsGameOver[1].texte);
    libererTextures(textures);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(fenetre);
    TTF_CloseFont(police);
    TTF_Quit();
    SDL_Quit();
    return 0;
}
